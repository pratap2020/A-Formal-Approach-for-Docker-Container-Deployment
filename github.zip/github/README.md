
# "A Formal Approach for Docker Container Deployment"
TO install the CWB-NC tool form the website: https://sourceforge.net/projects/cwb-nc/
Run the .exe file.
These are commands used in CWB-NC tool for uploading and run simulate the experiment:-
1. ls :- ls command can be used for listing the name for variables such as agets, variables, etc.
2. load:- load command can be used to load your CCS (.ccs) and MU (.mu) file into the current CWB-NC
session.
3. size:- size command can be used to built an automaton that describe the behavior of agent of that
model and also represent the number of states and transitions in that model.
4. compile: compile command can be used to display a textual representation of the constructed model.
5. chk:- chk command invokes the model checker to determine whether or not agent satisfies formula to
given model.

